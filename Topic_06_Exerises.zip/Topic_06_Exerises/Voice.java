/* 
 * Exercise 1
 * Very Simple Method example
*/

public class Voice {
	// define the shout method
	public static void shout() {
		System.out.println("Hello Java");
	}

	public static void main(String[] args) {
		// call the shout method
		shout();
	}
}
