/* 
 * Exercise 4
 * Overloading example - but cant over load it ?
*/

public class Overloading2 {
	
	// define the Overloading main
	public static void main() {
		System.out.println("This is the overloading main");	
	}
	// define the 1st main
	public static void main(String [] args) {
		System.out.println("This is the original main");	
	}
}
