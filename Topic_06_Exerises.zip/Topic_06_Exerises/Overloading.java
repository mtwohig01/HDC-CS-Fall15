/* 
 * Exercise 4
 * Overloading example
*/

public class Overloading {
	// define the first main

	public static void main(String[] args) {
		System.out.println("This is the 1st main");	
	}
	// define the second main
	public static void main() {
		System.out.println("This is the 2nd main");	
	}

}
