/* 
 * Exercise 3
 * Reads in user input and splits the sentance into words on seperate lines
*/

import java.util.Scanner;

public class Upper {
	public static void main(String[] args) {
		// Get the Sentance from the Useri
		System.out.println("Please Enter a Sentance");
		Scanner sc = new Scanner(System.in);
		String userInput = sc.next();
		while ( sc.hasNext() ) {
			// Print it out to the console
			System.out.println( userInput );
			userInput = sc.next();
		}
	}
}
