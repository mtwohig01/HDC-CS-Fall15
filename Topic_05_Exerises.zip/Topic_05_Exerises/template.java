/* 
 * Exercise 6
 * Print first 40 Primes
*/

import java.util.Scanner;

public class FirstForty {
	public static void main(String[] args) {
		int num_of_primes=40,i,j;
		
		}
}
