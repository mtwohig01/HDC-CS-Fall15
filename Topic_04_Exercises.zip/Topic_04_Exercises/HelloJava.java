/* 
 * Exercise 1
 * For Loop to display "Hello Java" 10 times;
*/

public class HelloJava {
    public static void main(String[] args) {
	for(int i=0;i<10;i++) {
		System.out.println("HelloJava");
		}
	}
}
