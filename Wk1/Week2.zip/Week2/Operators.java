/* 
 * Exercise 1
*/
public class Operators {
    public static void main(String[] args) {
        int x = 1000;
	int y = 35;
	int result = x / y;
	x++;
	System.out.println("x = " + x );
    }
}
