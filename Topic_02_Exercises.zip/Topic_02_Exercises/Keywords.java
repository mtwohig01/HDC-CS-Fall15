/* 
 * Exercise 1
*/
public class Keywords {
    public static void main(String[] args) {
        System.out.println("Keyword Testing");
    }
}
