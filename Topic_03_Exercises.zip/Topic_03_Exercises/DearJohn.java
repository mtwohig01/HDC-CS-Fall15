/* 
 * Exercise 1
*/

import java.util.Scanner;

public class DearJohn {
    public static void main(String[] args) {
        String johnsName;	
	System.out.println("Please Enter your Christian Name");
    	Scanner sc = new Scanner(System.in);
	johnsName = sc.next();
	System.out.println("Your name is " + johnsName);
	}
}
