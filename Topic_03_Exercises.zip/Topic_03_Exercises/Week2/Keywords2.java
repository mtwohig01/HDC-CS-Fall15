/* 
 * Exercise 1a
*/
public class Keywords2 {
    public static void main(String[] args) {
        System.out.println("Keyword");
	System.out.println("Testing");
    }
}
